import { useState, useEffect, useRef, useCallback } from "react";

// ─────────────────────────────────────────────────────────────────────────────
// GLOBAL CSS
// ─────────────────────────────────────────────────────────────────────────────
const GLOBAL_CSS = `
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Dancing+Script:wght@600;700&family=Lato:ital,wght@0,300;0,400;0,700;1,300;1,400&display=swap');
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body { background:#fff; overflow-x:hidden; font-family:'Lato',sans-serif; }
::-webkit-scrollbar { width:4px; }
::-webkit-scrollbar-track { background:#1a1a1a; }
::-webkit-scrollbar-thumb { background:linear-gradient(#c0392b,#F5C842); border-radius:2px; }

/* ── scroll progress ── */
#fc-progress {
  position:fixed; top:0; left:0; height:3px; z-index:3000;
  background:linear-gradient(90deg,#c0392b,#e8a200,#F5C842);
  width:0%; transition:width 0.08s linear;
  box-shadow:0 0 8px rgba(192,57,43,0.6);
}

/* ── responsive nav ── */
@media(max-width:860px){
  .fc-nav-links{ display:none!important; }
  .fc-hamburger{ display:flex!important; }
}

/* ── animated background lines ── */
.fc-lines-bg {
  position:absolute; inset:0; pointer-events:none; overflow:hidden; z-index:0;
}
.fc-lines-bg svg { position:absolute; inset:0; width:100%; height:100%; }

/* ── keyframes ── */
@keyframes lineFlow {
  from { stroke-dashoffset: 1000; }
  to   { stroke-dashoffset: 0; }
}
@keyframes linePulse {
  0%,100% { opacity:0.04; }
  50%      { opacity:0.09; }
}
@keyframes fadeUp {
  from { opacity:0; transform:translateY(38px); }
  to   { opacity:1; transform:translateY(0); }
}
@keyframes fadeLeft {
  from { opacity:0; transform:translateX(-38px); }
  to   { opacity:1; transform:translateX(0); }
}
@keyframes fadeRight {
  from { opacity:0; transform:translateX(38px); }
  to   { opacity:1; transform:translateX(0); }
}
@keyframes zoomIn {
  from { opacity:0; transform:scale(0.84); }
  to   { opacity:1; transform:scale(1); }
}
@keyframes slideDown {
  from { opacity:0; transform:translateY(-14px); }
  to   { opacity:1; transform:translateY(0); }
}
@keyframes bounceIn {
  0%  { opacity:0; transform:scale(0.72) translateY(36px); }
  60% { opacity:1; transform:scale(1.04) translateY(-4px); }
  100%{ transform:scale(1) translateY(0); }
}
@keyframes toastAnim {
  0%  { opacity:0; transform:translateX(-50%) translateY(50px) scale(0.9); }
  12% { opacity:1; transform:translateX(-50%) translateY(0) scale(1); }
  86% { opacity:1; transform:translateX(-50%) translateY(0) scale(1); }
  100%{ opacity:0; transform:translateX(-50%) translateY(30px) scale(0.9); }
}
@keyframes float {
  0%,100%{ transform:translateY(0); }
  50%    { transform:translateY(-12px); }
}
@keyframes pulseDot {
  0%,100%{ transform:scale(1); opacity:0.8; }
  50%    { transform:scale(1.7); opacity:0; }
}
@keyframes rotateLine {
  from { transform:rotate(0deg); }
  to   { transform:rotate(360deg); }
}
@keyframes dashMove {
  from { stroke-dashoffset:200; }
  to   { stroke-dashoffset:0; }
}
@keyframes shimmerSlide {
  0%  { background-position:-600px 0; }
  100%{ background-position:600px 0; }
}
@keyframes scaleX {
  from { transform:scaleX(0); }
  to   { transform:scaleX(1); }
}

/* ── ripple ── */
.fc-btn { position:relative; overflow:hidden; cursor:pointer; }
.fc-btn::after {
  content:""; position:absolute; border-radius:50%;
  background:rgba(255,255,255,0.28);
  width:100px; height:100px;
  top:var(--ry,50%); left:var(--rx,50%);
  transform:translate(-50%,-50%) scale(0);
  animation:rippleOut 0.55s ease-out;
  pointer-events:none;
}
@keyframes rippleOut {
  to { transform:translate(-50%,-50%) scale(4); opacity:0; }
}

/* ── card img zoom ── */
.fc-img-wrap { overflow:hidden; }
.fc-img-wrap img { transition:transform 0.5s cubic-bezier(.25,.8,.25,1); display:block; }
.fc-img-wrap:hover img { transform:scale(1.07); }
`;

// ─────────────────────────────────────────────────────────────────────────────
// DATA
// ─────────────────────────────────────────────────────────────────────────────
const NAV_LINKS = [
  { label:"Home",           id:"home" },
  { label:"Trending food",  id:"trending" },
  { label:"Recipes",        id:"recipes" },
  { label:"World cuisine",  id:"world" },
  { label:"Street food",    id:"categories" },
  { label:"Diet & healthy", id:"diet" },
  { label:"Food blog",      id:"latest" },
  { label:"About",          id:"about" },
  { label:"Contact",        id:"contact" },
];

const trendingPosts = [
  { title:"Korean Corn Dogs", date:"January 1, 2026", tag:"Trending",
    desc:"Crispy outside, cheesy inside! Golden fried corn dogs with gooey cheese and bold Korean flavors.",
    full:"Korean Corn Dogs took the internet by storm with their satisfying crunch and molten cheese pull. Originally popularized in Seoul's Myeongdong food alley, these skewered treats are coated in a sweet hot-dog batter (sometimes studded with sugar crystals for extra crisp) then deep-fried to golden perfection. Fillings range from mozzarella to tteok rice cake, and toppings include ketchup, mustard, or spicy mayo.",
    img:"https://images.unsplash.com/photo-1619518773079-e5e2c7b8e8d2?w=800&q=80" },
  { title:"Dubai Chocolate Bar", date:"January 1, 2026", tag:"Trending",
    desc:"Luxury in every bite. Rich chocolate layered with premium fillings inspired by Dubai desserts.",
    full:"The Dubai Chocolate Bar — known as 'Can't Get Knafeh of It' by Fix Dessert Chocolatier — went viral on social media for its dramatic pistachio-cream and shredded kataifi pastry filling encased in dark chocolate. The satisfying snap and creamy, nutty interior made it a must-try.",
    img:"https://images.unsplash.com/photo-1481391319762-47dff72954d9?w=800&q=80" },
  { title:"Viral Street Momo", date:"January 2, 2026", tag:"Trending",
    desc:"The internet's favourite street snack. Juicy Momo tossed in spicy sauces, full of desi street-style flavor.",
    full:"Street Momos have conquered India's street food scene and gone global thanks to social media. These steamed or pan-fried dumplings — originally from Nepal and Tibet — are stuffed with spiced minced meat or vegetables and served with a fiery tomato-chilli chutney. The trend of tossing finished momos in sauces has elevated the humble dumpling into a viral sensation.",
    img:"https://images.unsplash.com/photo-1625220194771-7ebdea0b70b9?w=800&q=80" },
  { title:"Japanese Soufflé Pancakes", date:"January 2, 2026", tag:"Trending",
    desc:"Soft, fluffy & cloud-like. Light-as-air pancakes that melt in your mouth with every bite.",
    full:"Japanese Soufflé Pancakes are a masterclass in airy texture. The secret? Carefully folding whipped egg whites into the batter, then cooking them in ring molds low-and-slow so they rise tall and jiggle like little pillows. Originating in Tokyo's trendy café scene, they became a worldwide breakfast obsession.",
    img:"https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=800&q=80" },
];

const worldFood = [
  { country:"India",  flag:"🇮🇳", dish:"Butter Chicken, Dosa",
    full:"India's culinary landscape is one of the world's most diverse. Butter Chicken (Murgh Makhani) is a rich tomato-cream curry invented in Delhi in the 1950s. Dosa — a crisp fermented rice crepe from South India — is served with coconut chutney and sambar. Other icons include Biryani, Rogan Josh, and the vast vegetarian spread of Gujarat.",
    img:"https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=600&q=80" },
  { country:"Korea",  flag:"🇰🇷", dish:"Galbi, Bibimbap",
    full:"Korean cuisine is built around bold fermented flavors and communal BBQ culture. Galbi (grilled short ribs) and Bibimbap — a vibrant rice bowl with seasoned vegetables, fried egg, and gochujang — are Korea's most recognized dishes abroad. The global K-food wave continues to spread.",
    img:"https://images.unsplash.com/photo-1498654896293-37aacf113fd9?w=600&q=80" },
  { country:"Italy",  flag:"🇮🇹", dish:"Pizza & Pasta",
    full:"Italian cuisine is the backbone of global comfort food. Neapolitan pizza uses San Marzano tomatoes, fior di latte mozzarella, and a char-kissed sourdough crust. Pasta alone has over 300 recognized shapes, each designed for a specific sauce.",
    img:"https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600&q=80" },
];

const recipes = [
  { title:"Masala Frankie Roll", date:"Jan 15, 2026",
    desc:"A spicy vegetable stuffing wrapped in soft roti with tangy sauce.",
    full:"The Mumbai Frankie is a beloved street snack. A soft wheat roti is layered with egg, then stuffed with spiced potatoes and veggies, raw onion, and a generous drizzle of green chutney and sweet chilli sauce. Our recipe adds paneer for extra protein.",
    prep:"20 min", cook:"15 min", serves:2,
    img:"https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=600&q=80" },
  { title:"Fruit Yogurt Bowl", date:"Jan 18, 2026",
    desc:"Fresh seasonal fruits blended with creamy low-fat yogurt. Rich in vitamins, protein and natural sweetness.",
    full:"This vibrant bowl starts with thick Greek yogurt sweetened with honey. Topped with sliced banana, kiwi, fresh berries, and a crunch of granola, it delivers a full spectrum of micronutrients. The combination of probiotics from yogurt and antioxidants from berries makes it a powerhouse breakfast.",
    prep:"5 min", cook:"0 min", serves:1,
    img:"https://images.unsplash.com/photo-1511690743698-d9d85f2fbf38?w=600&q=80" },
  { title:"Air Fryer Paneer Tikka", date:"Jan 20, 2026",
    desc:"Rich in protein and all spicy and rich flavours. A perfect air fryer snack.",
    full:"Marinate paneer cubes in yogurt with ginger-garlic, red chilli powder, garam masala, and lemon. Skewer with bell peppers and onion then air-fry at 200°C for 12 minutes. Each serving delivers 22 g of protein.",
    prep:"35 min", cook:"12 min", serves:3,
    img:"https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=600&q=80" },
  { title:"Dal Tadka & Rice", date:"Jan 22, 2026",
    desc:"Home-cooked lentils seasoned with aromatic Indian spices. Comfort food made with love.",
    full:"Yellow moong dal is pressure-cooked until silky, then tadka is poured over: ghee crackled with cumin, dried red chillies, garlic, and hing. Serve over steamed basmati rice. A complete protein meal under ₹80.",
    prep:"10 min", cook:"20 min", serves:4,
    img:"https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=600&q=80" },
];

const dietGuides = [
  { title:"Weight Loss Diet Foods", sub:"Quinoa Top Salad Bowl",
    desc:"Perfect low-calorie meal for weight loss.",
    full:"Our Quinoa Salad Bowl combines 80 g cooked quinoa, roasted chickpeas, cucumber, cherry tomatoes, and a lemon-tahini dressing. Under 380 calories, it keeps you full for 4+ hours.",
    img:"https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600&q=80" },
  { title:"High Protein Diet Foods", sub:"Power Protein Power Bowl",
    desc:"High-protein ingredients and healthy options.",
    full:"Our Power Bowl stacks grilled chicken breast, hard-boiled eggs, edamame, brown rice, and Greek yogurt dressing — delivering 48 g of protein per bowl.",
    img:"https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=600&q=80" },
  { title:"Keto Food List", sub:"Avocado-Egg Keto Plate",
    desc:"Great for the keto diet and low-carb lifestyle.",
    full:"Avocado paired with 3 scrambled eggs in butter, a strip of bacon, and spinach. This plate hits the 75% fat / 20% protein / 5% carb macro ratio perfectly.",
    img:"https://images.unsplash.com/photo-1482049016688-2d3e1b311543?w=600&q=80" },
];

const categories = [
  { name:"Street Food",  img:"https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=300&q=80" },
  { name:"Fast Food",    img:"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300&q=80" },
  { name:"Vegan Food",   img:"https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=300&q=80" },
  { name:"Fried Food",   img:"https://images.unsplash.com/photo-1541614101331-1a5a3a194e92?w=300&q=80" },
  { name:"Desserts",     img:"https://images.unsplash.com/photo-1488477181946-6428a0291777?w=300&q=80" },
  { name:"Snacks",       img:"https://images.unsplash.com/photo-1621939514649-280e2ee25f60?w=300&q=80" },
  { name:"Breakfast",    img:"https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?w=300&q=80" },
  { name:"Dinner",       img:"https://images.unsplash.com/photo-1544025162-d76594e8bb5c?w=300&q=80" },
];

const latestPosts = [
  { title:"Mexican Tacos",          tag:"Trending Food", img:"https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=500&q=80" },
  { title:"Avocado Salad",          tag:"Diet Food",     img:"https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=500&q=80" },
  { title:"Chocolate Cake",         tag:"Desserts",      img:"https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=500&q=80" },
  { title:"Samosa Plate",           tag:"Street Food",   img:"https://images.unsplash.com/photo-1601050690597-df0568f70950?w=500&q=80" },
  { title:"Spicy Chicken",          tag:"Trending Food", img:"https://images.unsplash.com/photo-1598103442097-8b74394b95c8?w=500&q=80" },
  { title:"Cheese Burger",          tag:"Fast Food",     img:"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&q=80" },
  { title:"Steamed Veg Momos",      tag:"Street Food",   img:"https://images.unsplash.com/photo-1625220194771-7ebdea0b70b9?w=500&q=80" },
  { title:"Loaded Veggie Sandwich", tag:"Breakfast",     img:"https://images.unsplash.com/photo-1481070414801-51fd732d7184?w=500&q=80" },
  { title:"Sprouts Salad Bowl",     tag:"Diet Food",     img:"https://images.unsplash.com/photo-1543339308-43e59d6b73a6?w=500&q=80" },
];

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────
function scrollTo(id) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior:"smooth", block:"start" });
}

function useInView(threshold = 0.1) {
  const ref = useRef(null);
  const [vis, setVis] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVis(true); obs.disconnect(); } },
      { threshold }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return [ref, vis];
}

function AnimBox({ children, delay=0, type="fadeUp", style={}, as="div" }) {
  const [ref, vis] = useInView();
  const anim = { fadeUp:`fadeUp 0.7s ease ${delay}s both`, fadeLeft:`fadeLeft 0.7s ease ${delay}s both`, fadeRight:`fadeRight 0.7s ease ${delay}s both`, zoomIn:`zoomIn 0.65s ease ${delay}s both` };
  const Tag = as;
  return (
    <Tag ref={ref} style={{ animation:vis ? anim[type]:"none", opacity:vis ? undefined:0, ...style }}>
      {children}
    </Tag>
  );
}

function Btn({ children, onClick, style={}, variant="red" }) {
  const btnRef = useRef(null);
  const vars = {
    red:    { background:"#c0392b", color:"#fff", border:"none" },
    outline:{ background:"none", color:"#fff", border:"1.5px solid rgba(255,255,255,0.75)" },
    dark:   { background:"#1a1a1a", color:"#fff", border:"none" },
    gold:   { background:"linear-gradient(135deg,#F5C842,#e8a200)", color:"#000", border:"none" },
  };
  const fire = (e) => {
    const btn = btnRef.current;
    if (btn) {
      const r = btn.getBoundingClientRect();
      btn.style.setProperty("--rx", `${e.clientX - r.left}px`);
      btn.style.setProperty("--ry", `${e.clientY - r.top}px`);
      btn.classList.remove("fc-btn");
      void btn.offsetWidth;
      btn.classList.add("fc-btn");
    }
    if (onClick) onClick(e);
  };
  return (
    <button ref={btnRef} onClick={fire} className="fc-btn"
      style={{ ...vars[variant], ...style, cursor:"pointer", fontFamily:"'Lato',sans-serif" }}>
      {children}
    </button>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ANIMATED LINES BACKGROUND
// ─────────────────────────────────────────────────────────────────────────────
function LinesBg({ color="#c0392b", opacity=0.12 }) {
  return (
    <div className="fc-lines-bg" aria-hidden>
      <svg viewBox="0 0 1440 600" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
        {/* Diagonal animated lines */}
        {[0,1,2,3,4,5,6,7,8].map(i => (
          <line key={`d${i}`}
            x1={i*200-400} y1={0} x2={i*200+200} y2={700}
            stroke={color}
            strokeWidth="1"
            strokeDasharray="8 18"
            style={{
              opacity,
              animation:`linePulse ${3 + i*0.4}s ease-in-out ${i*0.3}s infinite`,
              strokeDashoffset: 0,
            }}
          />
        ))}
        {/* Horizontal drifting lines */}
        {[80,200,330,470,580].map((y,i) => (
          <line key={`h${i}`}
            x1={0} y1={y} x2={1440} y2={y}
            stroke={color}
            strokeWidth="0.8"
            strokeDasharray="6 24"
            style={{
              opacity: opacity * 0.7,
              animation:`linePulse ${4 + i*0.5}s ease-in-out ${i*0.6}s infinite`,
            }}
          />
        ))}
        {/* Corner decorative arcs */}
        <circle cx={0} cy={0} r={180} fill="none" stroke={color} strokeWidth="1" strokeDasharray="4 12"
          style={{ opacity: opacity*0.6, animation:"linePulse 5s ease-in-out infinite" }} />
        <circle cx={1440} cy={600} r={200} fill="none" stroke={color} strokeWidth="1" strokeDasharray="4 12"
          style={{ opacity: opacity*0.6, animation:"linePulse 6s ease-in-out 1s infinite" }} />
      </svg>
    </div>
  );
}

// Dashed horizontal divider line (like in the footer logo bar from Canva)
function DashLine({ color="rgba(255,255,255,0.3)", width="100%", my=0 }) {
  return (
    <div style={{ width, margin:`${my}px auto`, display:"flex", alignItems:"center" }}>
      <svg width="100%" height="12">
        <line x1="0" y1="6" x2="100%" y2="6"
          stroke={color} strokeWidth="1.5" strokeDasharray="6 8"
          style={{ animation:"linePulse 3s ease-in-out infinite" }} />
      </svg>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SCROLL PROGRESS
// ─────────────────────────────────────────────────────────────────────────────
function ScrollProgress() {
  useEffect(() => {
    const bar = document.getElementById("fc-progress");
    if (!bar) return;
    const upd = () => {
      const pct = (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
      bar.style.width = `${Math.min(pct,100)}%`;
    };
    window.addEventListener("scroll", upd, { passive:true });
    return () => window.removeEventListener("scroll", upd);
  }, []);
  return <div id="fc-progress" />;
}

// ─────────────────────────────────────────────────────────────────────────────
// TOAST
// ─────────────────────────────────────────────────────────────────────────────
function Toast({ msg, onDone }) {
  useEffect(() => {
    const t = setTimeout(onDone, 3400);
    return () => clearTimeout(t);
  }, [onDone]);
  return (
    <div style={{
      position:"fixed", bottom:30, left:"50%",
      background:"#1a1a1a", color:"#fff",
      padding:"14px 28px", borderRadius:40,
      fontFamily:"'Lato',sans-serif", fontSize:14, fontWeight:600,
      boxShadow:"0 8px 32px rgba(0,0,0,0.4)",
      border:"1px solid rgba(245,200,66,0.3)",
      animation:"toastAnim 3.4s ease both",
      whiteSpace:"nowrap", zIndex:9999,
    }}>{msg}</div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MODAL
// ─────────────────────────────────────────────────────────────────────────────
function Modal({ item, onClose }) {
  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = ""; };
  }, []);
  if (!item) return null;
  return (
    <div onClick={onClose} style={{
      position:"fixed", inset:0, zIndex:6000,
      background:"rgba(0,0,0,0.72)", backdropFilter:"blur(10px)",
      display:"flex", alignItems:"center", justifyContent:"center", padding:20,
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        background:"#fff", borderRadius:20, maxWidth:660, width:"100%",
        maxHeight:"90vh", overflowY:"auto",
        animation:"bounceIn 0.48s cubic-bezier(.22,.68,0,1.2) both",
        boxShadow:"0 32px 80px rgba(0,0,0,0.35)",
      }}>
        <div style={{ position:"relative" }}>
          <img src={item.img} alt={item.title||item.country} style={{ width:"100%", height:250, objectFit:"cover", borderRadius:"20px 20px 0 0", display:"block" }} />
          <button onClick={onClose} style={{
            position:"absolute", top:14, right:14,
            background:"rgba(0,0,0,0.55)", color:"#fff", border:"none",
            borderRadius:"50%", width:34, height:34, fontSize:17, cursor:"pointer",
            display:"flex", alignItems:"center", justifyContent:"center",
          }}>✕</button>
          {(item.tag || item.sub) && (
            <span style={{
              position:"absolute", top:14, left:14,
              background:"#c0392b", color:"#fff",
              fontFamily:"'Lato',sans-serif", fontSize:10, fontWeight:700,
              letterSpacing:1.5, padding:"4px 12px", borderRadius:20,
              textTransform:"uppercase",
            }}>{item.tag || item.sub}</span>
          )}
        </div>
        <div style={{ padding:"26px 30px 34px" }}>
          {(item.prep || item.cook) && (
            <div style={{ display:"flex", gap:14, marginBottom:16, flexWrap:"wrap" }}>
              {item.prep && <MetaPill icon="⏱" txt={`Prep ${item.prep}`} />}
              {item.cook && <MetaPill icon="🔥" txt={`Cook ${item.cook}`} />}
              {item.serves && <MetaPill icon="🍽" txt={`Serves ${item.serves}`} />}
            </div>
          )}
          {item.date && <p style={{ fontFamily:"'Lato',sans-serif", fontSize:12, color:"#bbb", marginBottom:6 }}>{item.date}{item.tag ? ` · ${item.tag}` : ""}</p>}
          {item.flag && <p style={{ fontSize:28, marginBottom:4 }}>{item.flag}</p>}
          <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(20px,3vw,28px)", color:"#1a1a1a", marginBottom:10, lineHeight:1.25 }}>
            {item.title || item.country}
          </h2>
          {item.sub && <p style={{ fontFamily:"'Lato',sans-serif", fontSize:13, color:"#c0392b", fontStyle:"italic", marginBottom:10 }}>{item.sub}</p>}
          <p style={{ fontFamily:"'Lato',sans-serif", fontSize:15, color:"#444", lineHeight:1.9, marginBottom:22 }}>
            {item.full || item.desc}
          </p>
          <Btn onClick={onClose} variant="red"
            style={{ padding:"11px 28px", borderRadius:30, fontSize:13, fontWeight:700, letterSpacing:1 }}>
            ← BACK
          </Btn>
        </div>
      </div>
    </div>
  );
}
function MetaPill({ icon, txt }) {
  return (
    <span style={{ display:"inline-flex", alignItems:"center", gap:5, background:"#f5f5f5", border:"1px solid #eee", borderRadius:20, padding:"4px 12px", fontFamily:"'Lato',sans-serif", fontSize:12, color:"#555" }}>
      {icon} {txt}
    </span>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// NAVBAR — matches Canva: dark bg, logo left, search right, links below
// ─────────────────────────────────────────────────────────────────────────────
function Navbar({ onSearch }) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive]     = useState("Home");
  const [search, setSearch]     = useState("");

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", fn, { passive:true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    const close = () => setMenuOpen(false);
    document.addEventListener("click", close);
    return () => document.removeEventListener("click", close);
  }, [menuOpen]);

  const go = (link) => {
    setActive(link.label);
    setMenuOpen(false);
    scrollTo(link.id);
  };

  const doSearch = (e) => {
    e.preventDefault();
    if (search.trim()) { onSearch(search.trim()); }
  };

  return (
    <>
      <nav style={{
        position:"fixed", top:0, left:0, right:0, zIndex:1000,
        background: scrolled ? "rgba(10,10,10,0.98)" : "rgba(10,10,10,0.88)",
        backdropFilter:"blur(16px)",
        borderBottom: scrolled ? "1px solid rgba(255,255,255,0.06)" : "none",
        transition:"background 0.4s",
      }}>
        {/* Row 1: logo + search */}
        <div style={{ maxWidth:1280, margin:"0 auto", display:"flex", alignItems:"center", justifyContent:"space-between", padding:"12px 28px 8px" }}>
          <button onClick={() => scrollTo("home")} style={{ background:"none", border:"none", cursor:"pointer", display:"flex", alignItems:"center", gap:8 }}>
            <span style={{ color:"rgba(255,255,255,0.85)", fontSize:18, lineHeight:1 }}>🍴</span>
            <span style={{ fontFamily:"'Dancing Script',cursive", fontSize:24, color:"#fff", fontWeight:700, letterSpacing:0.5 }}>frycuisine</span>
            <span style={{ width:6, height:6, borderRadius:"50%", background:"#c0392b", marginLeft:2, marginBottom:10 }} />
          </button>

          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <form onSubmit={doSearch} style={{ position:"relative" }}>
              <span style={{ position:"absolute", left:12, top:"50%", transform:"translateY(-50%)", color:"#888", fontSize:13, pointerEvents:"none" }}>🔍</span>
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search recipes…"
                style={{
                  background:"rgba(255,255,255,0.08)", border:"1px solid rgba(255,255,255,0.15)",
                  borderRadius:22, color:"#fff", padding:"7px 36px 7px 34px",
                  fontSize:13, outline:"none", fontFamily:"'Lato',sans-serif",
                  width:190, transition:"width 0.3s, border-color 0.3s",
                }}
                onFocus={e => { e.target.style.width="240px"; e.target.style.borderColor="rgba(245,200,66,0.45)"; }}
                onBlur={e => { e.target.style.width="190px"; e.target.style.borderColor="rgba(255,255,255,0.15)"; }}
              />
              {search && (
                <button type="button" onClick={() => setSearch("")}
                  style={{ position:"absolute", right:10, top:"50%", transform:"translateY(-50%)", background:"none", border:"none", color:"#888", fontSize:15, cursor:"pointer", lineHeight:1 }}>✕</button>
              )}
            </form>
            <button className="fc-hamburger" onClick={e => { e.stopPropagation(); setMenuOpen(o=>!o); }}
              style={{ display:"none", background:"none", border:"1px solid rgba(255,255,255,0.25)", color:"#fff", fontSize:18, cursor:"pointer", padding:"5px 9px", borderRadius:6 }}>
              {menuOpen ? "✕" : "☰"}
            </button>
          </div>
        </div>

        {/* Row 2: nav links */}
        <div className="fc-nav-links" style={{ borderTop:"1px solid rgba(255,255,255,0.06)", display:"flex", justifyContent:"center", gap:2, padding:"6px 28px 10px" }}>
          {NAV_LINKS.map(link => (
            <button key={link.label} onClick={() => go(link)}
              style={{
                background: active===link.label ? "rgba(255,255,255,0.1)" : "none",
                border: active===link.label ? "1px solid rgba(255,255,255,0.2)" : "1px solid transparent",
                color: active===link.label ? "#F5C842" : "rgba(255,255,255,0.8)",
                padding:"5px 13px", borderRadius:18,
                fontSize:13, fontFamily:"'Lato',sans-serif",
                fontWeight: active===link.label ? 700 : 400,
                cursor:"pointer", transition:"all 0.2s", letterSpacing:0.2,
              }}
              onMouseEnter={e => { if (active!==link.label) { e.currentTarget.style.color="#F5C842"; e.currentTarget.style.background="rgba(255,255,255,0.06)"; } }}
              onMouseLeave={e => { if (active!==link.label) { e.currentTarget.style.color="rgba(255,255,255,0.8)"; e.currentTarget.style.background="none"; } }}
            >{link.label}</button>
          ))}
        </div>
      </nav>

      {/* Mobile menu */}
      <div onClick={e => e.stopPropagation()}
        style={{
          position:"fixed", top:0, left:0, right:0, zIndex:999,
          background:"rgba(10,10,10,0.97)", backdropFilter:"blur(16px)",
          maxHeight: menuOpen ? "100vh" : 0,
          overflow:"hidden",
          transition:"max-height 0.38s cubic-bezier(.4,0,.2,1)",
          paddingTop: menuOpen ? 80 : 0,
        }}
      >
        <div style={{ padding:"12px 20px 24px", display:"flex", flexDirection:"column", gap:3 }}>
          {NAV_LINKS.map((link,i) => (
            <button key={link.label} onClick={() => go(link)}
              style={{
                background: active===link.label ? "rgba(245,200,66,0.1)" : "none",
                border:"none",
                color: active===link.label ? "#F5C842" : "#fff",
                padding:"12px 16px", borderRadius:8, cursor:"pointer",
                fontSize:15, fontFamily:"'Lato',sans-serif", textAlign:"left",
                animation: menuOpen ? `slideDown 0.3s ease ${i*0.04}s both` : "none",
              }}
            >{link.label}</button>
          ))}
        </div>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// HERO — matches Canva: food image right, text left, dark bg
// ─────────────────────────────────────────────────────────────────────────────
function Hero() {
  const [rdy, setRdy] = useState(false);
  const [py, setPy]   = useState(0);

  useEffect(() => {
    setTimeout(() => setRdy(true), 80);
    const onScroll = () => setPy(window.scrollY * 0.28);
    window.addEventListener("scroll", onScroll, { passive:true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <section id="home" style={{
      position:"relative", minHeight:"100vh",
      background:"#111", display:"flex", alignItems:"center",
      overflow:"hidden", paddingTop:110,
    }}>
      {/* Animated lines bg — ultra-subtle */}
      <LinesBg color="#F5C842" opacity={0.022} />

      {/* Full-bleed dark vignette layer for depth */}
      <div style={{
        position:"absolute", inset:0, zIndex:1, pointerEvents:"none",
        background:"radial-gradient(ellipse at 30% 50%, transparent 30%, rgba(0,0,0,0.55) 100%)",
      }} />

      {/* Right-side food image */}
      <div style={{
        position:"absolute", right:0, top:0, width:"52%", height:"100%",
        transform:`translateY(${py}px)`,
        transition:"transform 0.05s linear",
        zIndex:0,
      }}>
        <img
          src="https://images.unsplash.com/photo-1547592180-85f173990554?w=1200&q=85"
          alt="food"
          style={{ width:"100%", height:"100%", objectFit:"cover", display:"block",
            filter:"brightness(0.78) saturate(1.1)" }}
        />
        {/* Left feather — blends image into dark bg */}
        <div style={{
          position:"absolute", inset:0,
          background:"linear-gradient(90deg,#111 0%,rgba(17,17,17,0.82) 28%,rgba(17,17,17,0.3) 58%,transparent 100%)",
        }} />
        {/* Top & bottom dark fade */}
        <div style={{
          position:"absolute", inset:0,
          background:"linear-gradient(180deg,rgba(17,17,17,0.45) 0%,transparent 25%,transparent 70%,rgba(17,17,17,0.6) 100%)",
        }} />
      </div>

      {/* Content left */}
      <div style={{ position:"relative", zIndex:2, maxWidth:1280, margin:"0 auto", padding:"0 40px 60px", width:"100%" }}>
        <div style={{ maxWidth:540 }}>
          <div style={{
            display:"inline-flex", alignItems:"center", gap:8,
            marginBottom:22,
            opacity: rdy ? 1:0,
            transform: rdy ? "none":"translateY(-14px)",
            transition:"all 0.6s ease 0.05s",
          }}>
            <span style={{ width:7, height:7, borderRadius:"50%", background:"#F5C842", boxShadow:"0 0 0 3px rgba(245,200,66,0.2)", animation:"pulseDot 1.5s ease-in-out infinite" }} />
            <span style={{ color:"rgba(255,255,255,0.55)", fontFamily:"'Lato',sans-serif", fontSize:11, letterSpacing:2.5, textTransform:"uppercase" }}>
              Food Stories · Live
            </span>
          </div>

          {/* Thin gold rule above headline */}
          <div style={{
            width:48, height:2,
            background:"linear-gradient(90deg,#F5C842,#c0392b)",
            borderRadius:1, marginBottom:20,
            opacity: rdy ? 1:0,
            transition:"opacity 0.8s ease 0.1s",
          }} />

          <h1 style={{
            fontFamily:"'Playfair Display',serif",
            fontSize:"clamp(34px,4.8vw,64px)",
            color:"#fff",
            lineHeight:1.12, marginBottom:16,
            opacity: rdy ? 1:0,
            transform: rdy ? "none":"translateY(40px)",
            transition:"all 0.9s ease 0.15s",
            letterSpacing:-0.5,
            textShadow:"0 4px 32px rgba(0,0,0,0.6)",
          }}>
            Explore Trending,{" "}
            <em style={{ color:"#F5C842", fontStyle:"italic" }}>Global</em>
            {" "}& Healthy Food at FryCuisine
          </h1>

          <p style={{
            fontFamily:"'Lato',sans-serif",
            fontSize:16, color:"rgba(255,255,255,0.62)",
            lineHeight:1.85, marginBottom:40,
            opacity: rdy ? 1:0,
            transform: rdy ? "none":"translateY(30px)",
            transition:"all 0.9s ease 0.3s",
            maxWidth:460,
          }}>
            From viral food trends and world-famous dishes to healthy diets and easy recipes — everything about food in one place.
          </p>

          <div style={{ display:"flex", gap:14, flexWrap:"wrap" }}>
            {[
              { label:"Explore Recipes", id:"recipes", v:"red" },
              { label:"World Cuisine ➤", id:"world",   v:"outline" },
            ].map((b,i) => (
              <Btn key={b.label} variant={b.v} onClick={() => scrollTo(b.id)}
                style={{
                  padding:"13px 30px", borderRadius:30, fontSize:13.5, fontWeight:700, letterSpacing:0.8,
                  opacity: rdy ? 1:0,
                  transform: rdy ? "none":"translateY(20px)",
                  transition:`all 0.8s ease ${0.5+i*0.14}s`,
                  backdropFilter:"blur(6px)",
                  textTransform:"uppercase",
                }}
              >{b.label}</Btn>
            ))}
          </div>

          {/* Divider + Stats */}
          <div style={{
            marginTop:52, opacity: rdy ? 1:0, transition:"opacity 1s ease 0.85s",
          }}>
            <div style={{ width:"100%", height:1, background:"rgba(255,255,255,0.08)", marginBottom:28 }} />
            <div style={{ display:"flex", gap:40, flexWrap:"wrap" }}>
            {[["500+","Recipes"],["80+","Countries"],["2M+","Readers"]].map(([n,l]) => (
              <div key={l}>
                <div style={{ fontFamily:"'Playfair Display',serif", fontSize:30, color:"#F5C842", fontWeight:700, lineHeight:1 }}>{n}</div>
                <div style={{ fontFamily:"'Lato',sans-serif", fontSize:10, color:"rgba(255,255,255,0.38)", letterSpacing:2, textTransform:"uppercase", marginTop:5 }}>{l}</div>
              </div>
            ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// TRENDING — matches Canva: 2×2 grid, large images, red titles, READ MORE…
// ─────────────────────────────────────────────────────────────────────────────
function TrendingSection({ onOpen }) {
  return (
    <section id="trending" style={{ background:"#fff", padding:"80px 40px", position:"relative", overflow:"hidden" }}>
      <LinesBg color="#c0392b" opacity={0.04} />
      <div style={{ position:"relative", zIndex:1, maxWidth:1280, margin:"0 auto" }}>
        <AnimBox type="zoomIn" style={{ textAlign:"center", marginBottom:52 }}>
          <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(26px,3.5vw,40px)", color:"#1a1a1a", letterSpacing:3, textTransform:"uppercase" }}>
            Trending Food Right Now
          </h2>
          <AnimBox type="fadeUp" delay={0.1} style={{ width:60, height:3, background:"linear-gradient(90deg,#c0392b,#F5C842)", borderRadius:2, margin:"14px auto 0", transformOrigin:"left" }} />
        </AnimBox>

        {/* 2×2 grid matching Canva */}
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(300px,1fr))", gap:32 }}>
          {trendingPosts.map((p,i) => (
            <AnimBox key={p.title} delay={i*0.1} type="fadeUp">
              <div
                onClick={() => onOpen(p)}
                style={{ cursor:"pointer" }}
                onMouseEnter={e => { e.currentTarget.querySelector(".fc-card-inner").style.boxShadow="0 16px 48px rgba(0,0,0,0.14)"; }}
                onMouseLeave={e => { e.currentTarget.querySelector(".fc-card-inner").style.boxShadow="none"; }}
              >
                <div className="fc-card-inner" style={{ transition:"box-shadow 0.3s", borderRadius:2 }}>
                  <div className="fc-img-wrap" style={{ borderRadius:2 }}>
                    <img src={p.img} alt={p.title} style={{ width:"100%", height:240, objectFit:"cover", display:"block" }} />
                  </div>
                  <div style={{ padding:"18px 4px 10px" }}>
                    <h3 style={{ fontFamily:"'Playfair Display',serif", fontSize:22, color:"#8B4513", marginBottom:6, lineHeight:1.25 }}>{p.title}</h3>
                    <p style={{ fontFamily:"'Lato',sans-serif", fontSize:12, color:"#aaa", marginBottom:10 }}>{p.date}  &nbsp; {p.tag}</p>
                    <p style={{ fontFamily:"'Lato',sans-serif", fontSize:14, color:"#555", lineHeight:1.7, marginBottom:14 }}>{p.desc}</p>
                    <button onClick={e => { e.stopPropagation(); onOpen(p); }}
                      style={{ background:"none", border:"none", color:"#8B4513", fontFamily:"'Lato',sans-serif", fontSize:12, fontWeight:700, cursor:"pointer", letterSpacing:1, textTransform:"uppercase", padding:0, transition:"color 0.2s" }}
                      onMouseEnter={e => e.currentTarget.style.color="#c0392b"}
                      onMouseLeave={e => e.currentTarget.style.color="#8B4513"}
                    >READ MORE…</button>
                  </div>
                </div>
              </div>
            </AnimBox>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// WORLD FOOD — horizontal country cards with READ MORE buttons
// ─────────────────────────────────────────────────────────────────────────────
function WorldFoodSection({ onOpen }) {
  return (
    <section id="world" style={{ background:"#fdf8f3", padding:"80px 40px", position:"relative", overflow:"hidden" }}>
      <LinesBg color="#c8a96e" opacity={0.08} />
      <div style={{ position:"relative", zIndex:1, maxWidth:1280, margin:"0 auto" }}>
        <AnimBox type="zoomIn" style={{ textAlign:"center", marginBottom:50 }}>
          <div style={{ display:"flex", alignItems:"center", gap:14, justifyContent:"center" }}>
            <DashLine color="#c8a96e" width="30%" />
            <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(18px,2.5vw,26px)", color:"#1a1a1a", whiteSpace:"nowrap" }}>
              World Famous Food by Country
            </h2>
            <DashLine color="#c8a96e" width="30%" />
          </div>
        </AnimBox>

        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(260px,1fr))", gap:28 }}>
          {worldFood.map((w,i) => (
            <AnimBox key={w.country} delay={i*0.12} type="zoomIn">
              <div style={{ background:"#fff", borderRadius:12, overflow:"hidden", boxShadow:"0 2px 16px rgba(0,0,0,0.07)", transition:"transform 0.3s cubic-bezier(.22,.68,0,1.2), box-shadow 0.3s", cursor:"pointer" }}
                onMouseEnter={e => { e.currentTarget.style.transform="translateY(-6px)"; e.currentTarget.style.boxShadow="0 16px 40px rgba(0,0,0,0.14)"; }}
                onMouseLeave={e => { e.currentTarget.style.transform="none"; e.currentTarget.style.boxShadow="0 2px 16px rgba(0,0,0,0.07)"; }}
                onClick={() => onOpen(w)}
              >
                <div className="fc-img-wrap">
                  <img src={w.img} alt={w.country} style={{ width:"100%", height:190, objectFit:"cover", display:"block" }} />
                </div>
                <div style={{ padding:"16px 20px 20px", textAlign:"center" }}>
                  <p style={{ fontSize:24 }}>{w.flag}</p>
                  <h3 style={{ fontFamily:"'Playfair Display',serif", fontSize:20, color:"#1a1a1a", margin:"4px 0 4px" }}>{w.country}</h3>
                  <p style={{ fontFamily:"'Lato',sans-serif", fontSize:13, color:"#888", marginBottom:14 }}>{w.dish}</p>
                  <Btn onClick={e => { e.stopPropagation(); onOpen(w); }} variant="red"
                    style={{ padding:"7px 22px", borderRadius:4, fontSize:11, fontWeight:700, letterSpacing:1.2, textTransform:"uppercase" }}>
                    READ MORE
                  </Btn>
                </div>
              </div>
            </AnimBox>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// RECIPES — Magazine style: big featured card left + side cards right
// ─────────────────────────────────────────────────────────────────────────────
function RecipesSection({ onOpen }) {
  const [showExtra, setShowExtra] = useState(false);

  // featured = first recipe, side = next 3, extra = rest
  const featured   = recipes[0];
  const sideCards  = recipes.slice(1, 4);
  const extraCards = recipes.slice(4);

  const SmallCard = ({ r, delay }) => (
    <AnimBox type="fadeRight" delay={delay}>
      <div
        onClick={() => onOpen(r)}
        style={{ display:"flex", gap:14, cursor:"pointer", padding:"14px 0",
          borderBottom:"1px solid #f0f0f0",
          transition:"background 0.2s",
        }}
        onMouseEnter={e => e.currentTarget.style.background="#fafafa"}
        onMouseLeave={e => e.currentTarget.style.background="transparent"}
      >
        <div className="fc-img-wrap" style={{ flexShrink:0, borderRadius:8, overflow:"hidden" }}>
          <img src={r.img} alt={r.title}
            style={{ width:90, height:75, objectFit:"cover", display:"block" }} />
        </div>
        <div style={{ display:"flex", flexDirection:"column", justifyContent:"center" }}>
          <p style={{ fontFamily:"'Lato',sans-serif", fontSize:10.5, color:"#bbb", marginBottom:3 }}>{r.date}</p>
          <h4 style={{
            fontFamily:"'Playfair Display',serif", fontSize:14.5, color:"#1a1a1a",
            lineHeight:1.35, marginBottom:5,
            transition:"color 0.2s",
          }}
            onMouseEnter={e => e.currentTarget.style.color="#c0392b"}
            onMouseLeave={e => e.currentTarget.style.color="#1a1a1a"}
          >{r.title}</h4>
          <button
            onClick={ev => { ev.stopPropagation(); onOpen(r); }}
            style={{ background:"none", border:"none", color:"#c0392b", fontSize:10.5,
              fontWeight:700, cursor:"pointer", fontFamily:"'Lato',sans-serif",
              letterSpacing:1, textTransform:"uppercase", padding:0, textAlign:"left" }}>
            CONTINUE READING ›
          </button>
        </div>
      </div>
    </AnimBox>
  );

  return (
    <section id="recipes" style={{ background:"#fff", padding:"80px 40px", position:"relative", overflow:"hidden" }}>
      <LinesBg color="#c0392b" opacity={0.03} />
      <div style={{ position:"relative", zIndex:1, maxWidth:1280, margin:"0 auto" }}>

        {/* Heading */}
        <AnimBox type="zoomIn" style={{ textAlign:"center", marginBottom:52 }}>
          <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(26px,3.5vw,40px)", color:"#1a1a1a", letterSpacing:3, textTransform:"uppercase" }}>
            Recipes Section
          </h2>
          <div style={{ width:60, height:3, background:"linear-gradient(90deg,#c0392b,#F5C842)", borderRadius:2, margin:"14px auto 0" }} />
        </AnimBox>

        {/* ── Magazine grid: featured left + side stack right ── */}
        <div style={{
          display:"grid",
          gridTemplateColumns:"1fr 1px 400px",
          gap:"0 40px",
          alignItems:"start",
        }}>
          {/* ── BIG FEATURED CARD ── */}
          <AnimBox type="fadeLeft" delay={0}>
            <div
              onClick={() => onOpen(featured)}
              style={{ cursor:"pointer" }}
            >
              {/* Full-width image with overlay badge */}
              <div className="fc-img-wrap" style={{ borderRadius:14, overflow:"hidden", position:"relative", marginBottom:24 }}>
                <img src={featured.img} alt={featured.title}
                  style={{ width:"100%", height:360, objectFit:"cover", display:"block" }} />
                {/* Gradient overlay at bottom */}
                <div style={{
                  position:"absolute", bottom:0, left:0, right:0, height:"45%",
                  background:"linear-gradient(transparent, rgba(0,0,0,0.55))",
                }} />
                {/* "FEATURED" pill */}
                <span style={{
                  position:"absolute", top:16, left:16,
                  background:"#c0392b", color:"#fff",
                  fontFamily:"'Lato',sans-serif", fontSize:10, fontWeight:700,
                  letterSpacing:2, textTransform:"uppercase",
                  padding:"5px 14px", borderRadius:20,
                }}>Featured Recipe</span>
                {/* Prep/cook pills bottom-left */}
                <div style={{ position:"absolute", bottom:16, left:16, display:"flex", gap:8 }}>
                  {[["⏱",featured.prep],["🔥",featured.cook],["🍽",`${featured.serves} servings`]].map(([ic,v]) => v && (
                    <span key={ic} style={{
                      background:"rgba(255,255,255,0.88)", color:"#333",
                      fontFamily:"'Lato',sans-serif", fontSize:11, fontWeight:700,
                      padding:"4px 10px", borderRadius:20,
                      display:"flex", alignItems:"center", gap:4,
                    }}>{ic} {v}</span>
                  ))}
                </div>
              </div>

              {/* Text block */}
              <p style={{ fontFamily:"'Lato',sans-serif", fontSize:12, color:"#bbb", marginBottom:8 }}>{featured.date}</p>
              <h2 style={{
                fontFamily:"'Playfair Display',serif",
                fontSize:"clamp(22px,2.8vw,34px)",
                color:"#1a1a1a", lineHeight:1.25, marginBottom:14,
                transition:"color 0.2s",
              }}
                onMouseEnter={e => e.currentTarget.style.color="#c0392b"}
                onMouseLeave={e => e.currentTarget.style.color="#1a1a1a"}
              >{featured.title}</h2>
              <p style={{ fontFamily:"'Lato',sans-serif", fontSize:15, color:"#555", lineHeight:1.8, marginBottom:22 }}>
                {featured.full || featured.desc}
              </p>
              <Btn
                onClick={ev => { ev.stopPropagation(); onOpen(featured); }}
                variant="red"
                style={{ padding:"12px 32px", borderRadius:30, fontSize:13, fontWeight:700, letterSpacing:1, display:"inline-flex", alignItems:"center", gap:8 }}
              >
                CONTINUE READING ›
              </Btn>
            </div>
          </AnimBox>

          {/* ── Vertical divider ── */}
          <div style={{ background:"#eee", width:1, alignSelf:"stretch", minHeight:300 }} />

          {/* ── SIDE SMALL CARDS ── */}
          <div>
            <p style={{ fontFamily:"'Lato',sans-serif", fontSize:11, color:"#c0392b", fontWeight:700, letterSpacing:2.5, textTransform:"uppercase", marginBottom:4 }}>
              More Recipes
            </p>
            <div style={{ width:32, height:2, background:"linear-gradient(90deg,#c0392b,#F5C842)", borderRadius:1, marginBottom:16 }} />
            {sideCards.map((r, i) => (
              <SmallCard key={r.title} r={r} delay={i * 0.1} />
            ))}

            {/* Extra cards revealed on toggle */}
            {showExtra && extraCards.map((r, i) => (
              <SmallCard key={r.title + "-x"} r={r} delay={i * 0.08} />
            ))}

            <AnimBox type="fadeUp" delay={0.35} style={{ marginTop:20 }}>
              <Btn
                onClick={() => setShowExtra(s => !s)}
                variant="dark"
                style={{
                  width:"100%", padding:"12px", borderRadius:8, fontSize:12,
                  fontWeight:700, letterSpacing:1.2, textTransform:"uppercase",
                  display:"flex", alignItems:"center", justifyContent:"center", gap:6,
                }}
              >
                {showExtra ? "SHOW LESS ↑" : "VIEW ALL RECIPES ↓"}
              </Btn>
            </AnimBox>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// DIET SECTION
// ─────────────────────────────────────────────────────────────────────────────
function DietSection({ onOpen }) {
  return (
    <section id="diet" style={{ background:"#fdf8f3", padding:"80px 40px", position:"relative", overflow:"hidden" }}>
      <LinesBg color="#c8a96e" opacity={0.07} />
      <div style={{ position:"relative", zIndex:1, maxWidth:1280, margin:"0 auto" }}>
        <AnimBox type="zoomIn" style={{ textAlign:"center", marginBottom:48 }}>
          <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(24px,3.5vw,40px)", color:"#1a1a1a", letterSpacing:3, textTransform:"uppercase" }}>
            Diet & Healthy Food Guides
          </h2>
          <div style={{ width:60, height:3, background:"linear-gradient(90deg,#c0392b,#F5C842)", borderRadius:2, margin:"14px auto 0" }} />
        </AnimBox>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(260px,1fr))", gap:28 }}>
          {dietGuides.map((d,i) => (
            <AnimBox key={d.title} delay={i*0.12} type="fadeUp">
              <div style={{ background:"#fff", borderRadius:12, overflow:"hidden", cursor:"pointer", transition:"transform 0.3s cubic-bezier(.22,.68,0,1.2), box-shadow 0.3s" }}
                onMouseEnter={e => { e.currentTarget.style.transform="translateY(-6px)"; e.currentTarget.style.boxShadow="0 16px 40px rgba(0,0,0,0.12)"; }}
                onMouseLeave={e => { e.currentTarget.style.transform="none"; e.currentTarget.style.boxShadow="none"; }}
                onClick={() => onOpen(d)}
              >
                <div className="fc-img-wrap">
                  <img src={d.img} alt={d.title} style={{ width:"100%", height:185, objectFit:"cover", display:"block" }} />
                </div>
                <div style={{ padding:"18px 20px 22px" }}>
                  <h3 style={{ fontFamily:"'Playfair Display',serif", fontSize:17, color:"#1a1a1a", marginBottom:4 }}>{d.title}</h3>
                  <p style={{ fontFamily:"'Lato',sans-serif", fontSize:13, fontStyle:"italic", color:"#c0392b", marginBottom:8 }}>{d.sub}</p>
                  <p style={{ fontFamily:"'Lato',sans-serif", fontSize:13, color:"#666", marginBottom:16, lineHeight:1.6 }}>{d.desc}</p>
                  <Btn onClick={e => { e.stopPropagation(); onOpen(d); }} variant="red"
                    style={{ padding:"7px 20px", borderRadius:4, fontSize:11, fontWeight:700, letterSpacing:1.2, textTransform:"uppercase" }}>
                    READ MORE
                  </Btn>
                </div>
              </div>
            </AnimBox>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────
// CATEGORY CIRCLE — individual circle with hover animations
// ─────────────────────────────────────────────────────────────────────────────
function CatCircle({ cat, active, onClick }) {
  const [hovered, setHovered] = useState(false);
  const isActive = active === cat.name;
  const lit = hovered || isActive;
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ textAlign:"center", cursor:"pointer", width:110 }}
    >
      {/* Outer ring that spins in on hover */}
      <div style={{
        position:"relative", display:"inline-block",
        borderRadius:"50%",
        padding:4,
        background: lit
          ? "linear-gradient(135deg,#c0392b,#F5C842)"
          : "transparent",
        boxShadow: lit ? "0 8px 28px rgba(192,57,43,0.35)" : "none",
        transition:"background 0.35s, box-shadow 0.35s",
        marginBottom:12,
      }}>
        {/* White gap ring */}
        <div style={{
          borderRadius:"50%", padding:3,
          background: lit ? "#fff" : "transparent",
          transition:"background 0.3s",
        }}>
          <img
            src={cat.img}
            alt={cat.name}
            style={{
              width:100, height:100, borderRadius:"50%", objectFit:"cover",
              display:"block",
              transform: lit ? "scale(1.1)" : "scale(1)",
              transition:"transform 0.4s cubic-bezier(.22,.68,0,1.3)",
              filter: lit ? "brightness(1.08) saturate(1.15)" : "none",
            }}
          />
        </div>

        {/* Active check badge */}
        {isActive && (
          <span style={{
            position:"absolute", bottom:4, right:4,
            background:"#c0392b", borderRadius:"50%",
            width:22, height:22,
            display:"flex", alignItems:"center", justifyContent:"center",
            fontSize:12, color:"#fff",
            boxShadow:"0 2px 8px rgba(0,0,0,0.25)",
            animation:"bounceIn 0.3s ease",
          }}>✓</span>
        )}
      </div>

      {/* Label */}
      <p style={{
        fontFamily:"'Lato',sans-serif", fontSize:12.5, fontWeight:700,
        color: lit ? "#c0392b" : "#444",
        letterSpacing:0.5,
        transform: hovered ? "translateY(-2px)" : "translateY(0)",
        transition:"color 0.3s, transform 0.3s",
      }}>
        {cat.name}
      </p>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// CATEGORIES — "Explore Food by Category" in Dancing Script (matches Canva)
// ─────────────────────────────────────────────────────────────────────────────
function CategoriesSection({ onToast }) {
  const [active, setActive] = useState(null);
  return (
    <section id="categories" style={{ background:"#fff", padding:"80px 40px", position:"relative", overflow:"hidden" }}>
      <LinesBg color="#c0392b" opacity={0.04} />
      <div style={{ position:"relative", zIndex:1, maxWidth:1280, margin:"0 auto" }}>
        <AnimBox type="zoomIn" style={{ textAlign:"center", marginBottom:50 }}>
          <p style={{ fontFamily:"'Lato',sans-serif", fontSize:12, color:"#bbb", letterSpacing:2.5, textTransform:"uppercase", marginBottom:8 }}>EXPLORE FOOD BY</p>
          <h2 style={{ fontFamily:"'Dancing Script',cursive", fontSize:"clamp(36px,5vw,56px)", color:"#1a1a1a" }}>Category</h2>
          <div style={{ width:60, height:3, background:"linear-gradient(90deg,#c0392b,#F5C842)", borderRadius:2, margin:"14px auto 0" }} />
        </AnimBox>

        <div style={{
          display:"flex", flexWrap:"wrap", justifyContent:"center",
          gap:"28px 32px",
        }}>
          {categories.map((cat,i) => (
            <AnimBox key={cat.name} delay={i*0.055} type="zoomIn">
              <CatCircle
                cat={cat}
                active={active}
                onClick={() => { setActive(cat.name); onToast(`Browsing ${cat.name} 🍽️`); }}
              />
            </AnimBox>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// LATEST POSTS — dark bg, dense card grid matching Canva
// ─────────────────────────────────────────────────────────────────────────────
function LatestSection({ onOpen }) {
  return (
    <section id="latest" style={{ background:"#0f0f0f", padding:"80px 40px", position:"relative", overflow:"hidden" }}>
      <LinesBg color="#F5C842" opacity={0.06} />
      <div style={{ position:"relative", zIndex:1, maxWidth:1280, margin:"0 auto" }}>
        <AnimBox type="zoomIn" style={{ textAlign:"center", marginBottom:48 }}>
          <p style={{ fontFamily:"'Lato',sans-serif", fontSize:12, color:"rgba(255,255,255,0.35)", letterSpacing:2.5, textTransform:"uppercase", marginBottom:6 }}>FOOD BLOG</p>
          <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(26px,3.5vw,40px)", color:"#fff", letterSpacing:1 }}>
            Latest from <em style={{ color:"#F5C842", fontStyle:"italic" }}>frycuisine</em>
          </h2>
          <div style={{ width:60, height:3, background:"linear-gradient(90deg,#c0392b,#F5C842)", borderRadius:2, margin:"14px auto 0" }} />
        </AnimBox>

        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))", gap:16 }}>
          {latestPosts.map((p,i) => (
            <AnimBox key={p.title} delay={i*0.06} type="zoomIn">
              <div
                onClick={() => onOpen({ ...p, full:`Discover everything about ${p.title} — how it's made, where it comes from, and why food lovers all over the world can't stop talking about it.` })}
                style={{ position:"relative", borderRadius:10, overflow:"hidden", cursor:"pointer",
                  transition:"transform 0.35s cubic-bezier(.22,.68,0,1.2), box-shadow 0.35s" }}
                onMouseEnter={e => { e.currentTarget.style.transform="translateY(-7px) scale(1.02)"; e.currentTarget.style.boxShadow="0 20px 40px rgba(245,200,66,0.12)"; }}
                onMouseLeave={e => { e.currentTarget.style.transform="none"; e.currentTarget.style.boxShadow="none"; }}
              >
                <div className="fc-img-wrap">
                  <img src={p.img} alt={p.title} style={{ width:"100%", height:160, objectFit:"cover", display:"block" }} />
                </div>
                <div style={{ position:"absolute", inset:0, background:"linear-gradient(transparent 45%,rgba(0,0,0,0.85))", display:"flex", flexDirection:"column", justifyContent:"flex-end", padding:"12px 12px 14px" }}>
                  <span style={{ color:"#F5C842", fontFamily:"'Lato',sans-serif", fontSize:9, fontWeight:700, textTransform:"uppercase", letterSpacing:1.5 }}>{p.tag}</span>
                  <p style={{ color:"#fff", fontFamily:"'Playfair Display',serif", fontSize:13, lineHeight:1.3, marginTop:3 }}>{p.title}</p>
                </div>
              </div>
            </AnimBox>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ABOUT / WHY
// ─────────────────────────────────────────────────────────────────────────────
function AboutSection() {
  return (
    <section id="about" style={{ background:"#fff", padding:"80px 40px", position:"relative", overflow:"hidden" }}>
      <LinesBg color="#c0392b" opacity={0.035} />
      <div style={{ position:"relative", zIndex:1, maxWidth:1280, margin:"0 auto", display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(300px,1fr))", gap:56, alignItems:"center" }}>
        <AnimBox type="fadeLeft">
          <div style={{ position:"relative" }}>
            <img src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=700&q=80" alt="About"
              style={{ width:"100%", borderRadius:16, objectFit:"cover", height:360, display:"block" }} />
            <div style={{
              position:"absolute", bottom:-18, right:-18,
              background:"linear-gradient(135deg,#c0392b,#8B2500)",
              borderRadius:12, padding:"16px 22px", color:"#fff",
              fontFamily:"'Playfair Display',serif",
              boxShadow:"0 12px 32px rgba(192,57,43,0.3)",
            }}>
              <div style={{ fontSize:26, fontWeight:700 }}>500+</div>
              <div style={{ fontSize:11, opacity:0.8, fontFamily:"'Lato',sans-serif" }}>Recipes Published</div>
            </div>
          </div>
        </AnimBox>
        <AnimBox type="fadeRight">
          <div>
            <p style={{ color:"#c0392b", fontFamily:"'Lato',sans-serif", fontSize:12, fontWeight:700, letterSpacing:2, marginBottom:10, textTransform:"uppercase" }}>Our Story</p>
            <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(24px,3vw,36px)", color:"#1a1a1a", marginBottom:18, lineHeight:1.25 }}>
              Why Food Lovers Choose FryCuisine
            </h2>
            <p style={{ fontFamily:"'Lato',sans-serif", fontSize:15, color:"#555", lineHeight:1.9, marginBottom:28 }}>
              FryCuisine brings you global food coverage in a simple and honest way. From easy recipes and real food guides to trending viral food updates, everything is shared cleanly. Our content helps food lovers explore new dishes, learn quickly, and enjoy authentic food stories without long or complicated text.
            </p>
            <div style={{ display:"flex", gap:28, flexWrap:"wrap" }}>
              {[["🌍","Global Coverage"],["🥗","Healthy Focus"],["📸","Visual Stories"]].map(([e,l]) => (
                <div key={l} style={{ display:"flex", alignItems:"center", gap:8 }}>
                  <span style={{ fontSize:18 }}>{e}</span>
                  <span style={{ fontFamily:"'Lato',sans-serif", fontSize:13, fontWeight:700, color:"#333" }}>{l}</span>
                </div>
              ))}
            </div>
          </div>
        </AnimBox>
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// FOOTER — 4-column magazine layout matching reference image
//   Col1: Trending featured card with image + meta + share icons
//   Col2: "Don't miss" article list with coloured category pills
//   Col3: Useful Links plain text list
//   Col4: About FryCuisine photo + description
//   Bottom bar: Powered by · email input · SUBSCRIBE · social icon circles
// ─────────────────────────────────────────────────────────────────────────────
function Footer({ onToast, onOpen }) {
  const [email, setEmail] = useState("");

  const subscribe = () => {
    if (!email.trim() || !email.includes("@")) {
      onToast("⚠️ Please enter a valid email address.");
      return;
    }
    setEmail("");
    onToast("🎉 You're subscribed! Welcome to FryCuisine.");
  };

  // coloured pills per category — keeps FryCuisine palette
  const pillColor = {
    "Trending Food": "#c0392b",
    "Diet Food":     "#27ae60",
    "Desserts":      "#8e44ad",
    "Street Food":   "#e67e22",
    "Fast Food":     "#2980b9",
    "Breakfast":     "#16a085",
    "Snacks":        "#d35400",
  };

  const socials = [
    { icon:"f",  name:"Facebook",  bg:"#1877F2" },
    { icon:"📷", name:"Instagram", bg:"#E1306C" },
    { icon:"𝕏",  name:"Twitter",   bg:"#1DA1F2" },
    { icon:"P",  name:"Pinterest", bg:"#E60023" },
    { icon:"▶",  name:"YouTube",   bg:"#FF0000" },
  ];

  // divider between columns
  const colBorder = "1px solid rgba(255,255,255,0.09)";
  const colPad    = "44px 32px";
  const headStyle = {
    fontFamily:"'Playfair Display',serif", fontSize:18, fontWeight:700,
    color:"#fff", marginBottom:20, paddingBottom:12,
    borderBottom:"2px solid #c0392b", display:"inline-block",
  };
  const linkStyle = {
    background:"none", border:"none", color:"rgba(255,255,255,0.68)",
    fontFamily:"'Lato',sans-serif", fontSize:14, cursor:"pointer", padding:"5px 0",
    display:"block", textAlign:"left", transition:"color 0.2s, paddingLeft 0.2s",
    width:"100%",
  };

  return (
    <footer id="contact" style={{
      position:"relative", overflow:"hidden",
      backgroundColor:"#111",
      backgroundImage:"url(https://images.unsplash.com/photo-1547592180-85f173990554?w=1400&q=20)",
      backgroundSize:"cover", backgroundBlendMode:"multiply",
      color:"#fff",
    }}>
      <LinesBg color="#F5C842" opacity={0.05} />

      {/* ── 4-column main area ── */}
      <div style={{
        position:"relative", zIndex:1,
        maxWidth:1280, margin:"0 auto",
        display:"grid",
        gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",
        borderBottom:"1px solid rgba(255,255,255,0.09)",
      }}>

        {/* ── COL 1: Trending featured card ── */}
        <AnimBox type="fadeUp" delay={0} style={{ padding:colPad, borderRight:colBorder }}>
          <h4 style={headStyle}>Trending</h4>
          <div
            onClick={() => onOpen(trendingPosts[0])}
            style={{ cursor:"pointer" }}
          >
            <div className="fc-img-wrap" style={{ borderRadius:6, overflow:"hidden", marginBottom:14 }}>
              <img
                src={trendingPosts[0].img}
                alt={trendingPosts[0].title}
                style={{ width:"100%", height:170, objectFit:"cover", display:"block" }}
              />
            </div>
            <p style={{ fontFamily:"'Lato',sans-serif", fontSize:11, color:"rgba(255,255,255,0.4)", marginBottom:8, display:"flex", alignItems:"center", gap:5 }}>
              <span>📅</span> {trendingPosts[0].date}
            </p>
            <h3 style={{ fontFamily:"'Playfair Display',serif", fontSize:17, color:"#fff", lineHeight:1.4, marginBottom:14, transition:"color 0.2s" }}
              onMouseEnter={e => e.currentTarget.style.color="#F5C842"}
              onMouseLeave={e => e.currentTarget.style.color="#fff"}
            >
              {trendingPosts[0].title}
            </h3>
            {/* Share/like row */}
            <div style={{ display:"flex", gap:16, alignItems:"center" }}>
              {[["💬","1"],["❤️","3"],["↗",""]].map(([ic, count], i) => (
                <button key={i} onClick={e => { e.stopPropagation(); onToast("Thanks for the interaction!"); }}
                  style={{ background:"none", border:"none", color:"rgba(255,255,255,0.45)", cursor:"pointer", display:"flex", alignItems:"center", gap:4, fontSize:13, fontFamily:"'Lato',sans-serif", padding:0, transition:"color 0.2s" }}
                  onMouseEnter={e => e.currentTarget.style.color="#F5C842"}
                  onMouseLeave={e => e.currentTarget.style.color="rgba(255,255,255,0.45)"}
                >
                  <span>{ic}</span>{count && <span>{count}</span>}
                </button>
              ))}
            </div>
          </div>
        </AnimBox>

        {/* ── COL 2: Don't miss ── */}
        <AnimBox type="fadeUp" delay={0.08} style={{ padding:colPad, borderRight:colBorder }}>
          <h4 style={headStyle}>Don't miss</h4>
          <div style={{ display:"flex", flexDirection:"column", gap:22 }}>
            {latestPosts.slice(0,3).map((p,i) => (
              <div key={p.title} onClick={() => onOpen({ ...p, full:`Discover the full story of ${p.title} — the flavors, the origins, and why it's a must-try.` })}
                style={{ cursor:"pointer", paddingBottom:22, borderBottom: i < 2 ? "1px solid rgba(255,255,255,0.07)" : "none" }}
              >
                <span style={{
                  display:"inline-block",
                  background: pillColor[p.tag] || "#c0392b",
                  color:"#fff",
                  fontFamily:"'Lato',sans-serif", fontSize:10, fontWeight:700,
                  letterSpacing:1.2, textTransform:"uppercase",
                  padding:"3px 10px", borderRadius:3, marginBottom:8,
                }}>
                  {p.tag}
                </span>
                <h3 style={{ fontFamily:"'Playfair Display',serif", fontSize:15, color:"#fff", lineHeight:1.4, marginBottom:6, transition:"color 0.2s" }}
                  onMouseEnter={e => e.currentTarget.style.color="#F5C842"}
                  onMouseLeave={e => e.currentTarget.style.color="#fff"}
                >
                  {p.title}
                </h3>
                <p style={{ fontFamily:"'Lato',sans-serif", fontSize:11, color:"rgba(255,255,255,0.38)", display:"flex", alignItems:"center", gap:4 }}>
                  <span>📅</span> January {5 + i * 7}, 2026
                </p>
              </div>
            ))}
          </div>
        </AnimBox>

        {/* ── COL 3: Useful Links ── */}
        <AnimBox type="fadeUp" delay={0.15} style={{ padding:colPad, borderRight:colBorder }}>
          <h4 style={headStyle}>Useful Links</h4>
          <nav style={{ display:"flex", flexDirection:"column" }}>
            {[
              ["About us",            "about"],
              ["Contact us",          "contact"],
              ["Newsletter",          "contact"],
              ["Trending Food",       "trending"],
              ["World Cuisine",       "world"],
              ["Diet & Healthy",      "diet"],
              ["Categories",          "categories"],
              ["Food Blog",           "latest"],
            ].map(([label, id]) => (
              <button key={label} onClick={() => scrollTo(id)} style={linkStyle}
                onMouseEnter={e => { e.currentTarget.style.color="#F5C842"; e.currentTarget.style.paddingLeft="8px"; }}
                onMouseLeave={e => { e.currentTarget.style.color="rgba(255,255,255,0.68)"; e.currentTarget.style.paddingLeft="0"; }}
              >
                {label}
              </button>
            ))}
          </nav>
        </AnimBox>

        {/* ── COL 4: About FryCuisine ── */}
        <AnimBox type="fadeUp" delay={0.22} style={{ padding:colPad }}>
          <h4 style={headStyle}>About FryCuisine</h4>
          <div className="fc-img-wrap" style={{ borderRadius:6, overflow:"hidden", marginBottom:16 }}>
            <img
              src="https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&q=80"
              alt="About FryCuisine"
              style={{ width:"100%", height:140, objectFit:"cover", display:"block" }}
            />
          </div>
          <p style={{ fontFamily:"'Lato',sans-serif", fontSize:14, color:"rgba(255,255,255,0.62)", lineHeight:1.8 }}>
            FryCuisine is one of the most elegant and creative food blogs — covering global cuisines, viral trends, healthy diets, and easy recipes. Your unique food story, told simply and beautifully.
          </p>
        </AnimBox>
      </div>

      {/* ── Bottom bar: Powered by · email · social icons ── */}
      <div style={{ position:"relative", zIndex:1, background:"rgba(0,0,0,0.35)" }}>
        <div style={{
          maxWidth:1280, margin:"0 auto",
          display:"flex", alignItems:"center", justifyContent:"space-between",
          flexWrap:"wrap", gap:16, padding:"18px 32px",
        }}>
          {/* Powered by */}
          <p style={{ fontFamily:"'Lato',sans-serif", fontSize:13, color:"rgba(255,255,255,0.45)", whiteSpace:"nowrap" }}>
            Powered by{" "}
            <button onClick={() => scrollTo("home")} style={{ background:"none", border:"none", color:"#F5C842", fontWeight:700, cursor:"pointer", fontFamily:"'Lato',sans-serif", fontSize:13, padding:0 }}>
              frycuisine
            </button>
          </p>

          {/* Email subscribe */}
          <div style={{ display:"flex", flex:"1", maxWidth:420, minWidth:260 }}>
            <input
              value={email}
              onChange={e => setEmail(e.target.value)}
              onKeyDown={e => e.key==="Enter" && subscribe()}
              placeholder="Please enter your e-mail"
              style={{
                flex:1, padding:"10px 16px",
                border:"1px solid rgba(255,255,255,0.15)", borderRight:"none",
                borderRadius:"4px 0 0 4px",
                background:"rgba(255,255,255,0.07)", color:"#fff",
                fontSize:13, outline:"none", fontFamily:"'Lato',sans-serif",
              }}
            />
            <Btn onClick={subscribe} variant="red"
              style={{
                padding:"10px 20px", borderRadius:"0 4px 4px 0",
                fontSize:12, fontWeight:700, letterSpacing:1.2, textTransform:"uppercase", whiteSpace:"nowrap",
              }}>
              SUBSCRIBE
            </Btn>
          </div>

          {/* Social circles */}
          <div style={{ display:"flex", gap:10 }}>
            {socials.map(s => (
              <button key={s.name} title={s.name}
                onClick={() => onToast(`Opening ${s.name}…`)}
                style={{
                  width:38, height:38, borderRadius:"50%",
                  background:s.bg, border:"none",
                  display:"flex", alignItems:"center", justifyContent:"center",
                  cursor:"pointer", fontSize:14, color:"#fff",
                  transition:"transform 0.25s, box-shadow 0.25s",
                  boxShadow:`0 3px 10px ${s.bg}55`,
                }}
                onMouseEnter={e => { e.currentTarget.style.transform="translateY(-4px) scale(1.15)"; e.currentTarget.style.boxShadow=`0 8px 20px ${s.bg}80`; }}
                onMouseLeave={e => { e.currentTarget.style.transform="none"; e.currentTarget.style.boxShadow=`0 3px 10px ${s.bg}55`; }}
              >{s.icon}</button>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ROOT
// ─────────────────────────────────────────────────────────────────────────────
export default function App() {
  const [modal, setModal] = useState(null);
  const [toast, setToast] = useState(null);

  const showToast = useCallback((msg) => {
    setToast(null);
    setTimeout(() => setToast(msg), 20);
  }, []);

  return (
    <>
      <style>{GLOBAL_CSS}</style>
      <ScrollProgress />
      <Navbar onSearch={q => q && showToast(`🔍 Searching for "${q}"…`)} />
      <Hero />
      <TrendingSection onOpen={setModal} />
      <WorldFoodSection onOpen={setModal} />
      <RecipesSection onOpen={setModal} />
      <DietSection onOpen={setModal} />
      <CategoriesSection onToast={showToast} />
      <LatestSection onOpen={setModal} />
      <AboutSection />
      <Footer onToast={showToast} onOpen={setModal} />
      {modal && <Modal item={modal} onClose={() => setModal(null)} />}
      {toast && <Toast key={toast + Date.now()} msg={toast} onDone={() => setToast(null)} />}
    </>
  );
}
