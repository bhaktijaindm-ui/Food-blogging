import FryCuisine from "./FryCuisine";

export default function App() {
  return <FryCuisine />;
}
